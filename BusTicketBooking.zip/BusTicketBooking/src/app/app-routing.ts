import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router'; 
import { BookBusComponent } from './components/book-bus/book-bus.component';
import { BusListComponent } from './components/bus-list/bus-list.component';
import { PassengerInfoComponent } from './components/passenger-info/passenger-info.component';
import { SearchBusesComponent } from './components/search-buses/search-buses.component';
import { ReviewTicketComponent } from './components/review-ticket/review-ticket.component';
import { HomeComponent } from './components/home/home.component';

const routes: Routes = [
    {path: 'home', component: HomeComponent},
    {path: '', component: HomeComponent},
    {path: 'search-buses', component: SearchBusesComponent},
    {path: 'bus-list', component: BusListComponent},
    {path: 'book/:id', component: BookBusComponent},
    {path: 'passenger-info', component: PassengerInfoComponent},
    {path: 'review-ticket', component: ReviewTicketComponent}
]; 

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
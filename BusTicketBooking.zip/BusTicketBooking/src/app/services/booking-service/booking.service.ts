import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  busSelected: any[] = [];
  seatsSelected: any[] = [];
  passengerDetails: any;

  constructor() { }

  updateSelectedSeats(seatsSelected: any) {
    this.seatsSelected = seatsSelected
  }

  setBusSelected(busSelected: any) {
    this.busSelected = busSelected
  }

  setPassengerDetails(passengerDetails: any) {
    this.passengerDetails = passengerDetails
  }

  getPassengerDetails() {
    return this.passengerDetails
  }

  getSelectedBus() {
    return this.busSelected
  }

  getSelectedSeats() {
    return this.seatsSelected
  }

}

import { Injectable , OnInit } from '@angular/core';
import * as busData from '../../../assets/files/bus.json';

@Injectable({
  providedIn: 'root'
})
export class BusService{

  busDetails: any[] = [];
  busFilterDetails: any[] = [];

  constructor() {
    this.busDetails = (busData as any).default;
   }

  getBusDetails() {
    return this.busDetails;
  }

  setBusFilterDetails(searchBusFormValues: any) {
    this.busFilterDetails = searchBusFormValues;
  }

  getBusFilterDetails() {
    return this.busFilterDetails;
  }

  getCitiesFrom() {
    return this.busDetails.map(item => item.From)
    .filter((value,index,self) => self.indexOf(value) === index)
  }

  getCitiesTo() {
    return this.busDetails.map(item => item.To)
    .filter((value,index,self) => self.indexOf(value) === index)
  }

  getBusById(id: any) {
    return this.busDetails.filter( (bus) => bus.Id==id)[0];
  }

}

import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing';

import { AppComponent } from './app.component';
import { SearchBusesComponent } from './components/search-buses/search-buses.component';
import { BusListComponent } from './components/bus-list/bus-list.component';
import { BookBusComponent } from './components/book-bus/book-bus.component';
import { PassengerInfoComponent } from './components/passenger-info/passenger-info.component';
import { ReviewTicketComponent } from './components/review-ticket/review-ticket.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { HomeComponent } from './components/home/home.component';

@NgModule({
  declarations: [
    AppComponent,
    SearchBusesComponent,
    BusListComponent,
    BookBusComponent,
    PassengerInfoComponent,
    ReviewTicketComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

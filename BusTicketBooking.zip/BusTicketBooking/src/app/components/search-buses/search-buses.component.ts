import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BusService } from '../../services/bus-service/bus.service';

@Component({
  selector: 'app-search-buses',
  templateUrl: './search-buses.component.html',
  styleUrls: ['./search-buses.component.css']
})
export class SearchBusesComponent implements OnInit {

  searchBusForm: FormGroup = this._formBuilder.group({});
  searchBusFormSubmitted: boolean = false;
  citiesFrom: string[] = [];
  citiesTo: string[] = [];

  constructor(private _formBuilder : FormBuilder, private _busService : BusService, private _router : Router){
    this.citiesFrom = _busService.getCitiesFrom();
    this.citiesTo = _busService.getCitiesTo();
    console.log(this.citiesFrom);
    console.log(this.citiesTo);
  }

  ngOnInit(): void {
    this.searchBusForm = this.setBusFormGroup(); 
  }

  setBusFormGroup() {
    return this._formBuilder.group({
      from: ['',Validators.required],
      to: ['',Validators.required],
      departureDate: ['',Validators.required]
      },
      {
       validator: this.mustNotMatch('from','to')
      });
  }

  mustNotMatch(from:string , to:string){
     return (formGroup : FormGroup) => {
      const _from = formGroup.controls[from];
      const _to = formGroup.controls[to];
            
      if((_from.value == _to.value) && _from.value!="")
        _to.setErrors({ mustNotMatch : true});
    }
  }

  
  get f(){
    return this.searchBusForm.controls;
  }


  onSearchBusFormSubmit() {
    this.searchBusFormSubmitted = true;
    
    if(this.searchBusForm.valid) {
      console.log(this.searchBusForm.value);
      this._busService.setBusFilterDetails(this.searchBusForm.value);
      this._router.navigateByUrl('/bus-list');
    }
    else
      return;
  }

}

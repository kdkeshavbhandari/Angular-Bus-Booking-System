import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { FormBuilder,FormControl, FormGroup, Validators } from '@angular/forms';
import { BookingService } from 'src/app/services/booking-service/booking.service';

@Component({
  selector: 'app-passenger-info',
  templateUrl: './passenger-info.component.html',
  styleUrls: ['./passenger-info.component.css']
})
export class PassengerInfoComponent implements OnInit {

  passengerForm: FormGroup = this._formBuilder.group({});
  passengerFormSubmitted: boolean = false

  constructor(private _formBuilder:FormBuilder, private _router: Router, private _bookingService: BookingService) { 
    this.passengerForm = this.setPassengerFormGroup()
  }

  ngOnInit(): void { }

  setPassengerFormGroup() {
    return this._formBuilder.group({
      name: ['',Validators.required],
      mobileNo: ['',[Validators.required, Validators.pattern("[0-9]{10}")]],
      email: ['',[Validators.required, Validators.email]]
      })
  }

  get f() {
    return this.passengerForm.controls;
  }


  onPassengerFormSubmit() {

    this.passengerFormSubmitted = true

    if(this.passengerForm.valid) {
      this.savePassengerDetails()
      this.navigateToReviewTicket()
    }
    else
      return
  }

  savePassengerDetails() {
    this._bookingService.setPassengerDetails(this.passengerForm.value)
  }

  navigateToReviewTicket() {
    this._router.navigateByUrl('/review-ticket')
  }

}
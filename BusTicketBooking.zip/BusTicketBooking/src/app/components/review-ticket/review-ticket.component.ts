import { Component, OnInit } from '@angular/core';
import { BookingService } from 'src/app/services/booking-service/booking.service';
import { BusService } from 'src/app/services/bus-service/bus.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-review-ticket',
  templateUrl: './review-ticket.component.html',
  styleUrls: ['./review-ticket.component.css']
})
export class ReviewTicketComponent implements OnInit {

  busBooked: any;
  seatsBooked: any;
  searchDetails: any;
  passengerDetails: any;
  
  getReviewTicket: boolean = true;
  ticketId: any;

  busKeys= {departureTime: "Dept. Time", to: "To", busName: "Bus Name", coachType: "Coach Type"}

  constructor(private _busBooking: BookingService, private _busService: BusService, private _router: Router) { 
    this.busBooked = _busBooking.getSelectedBus()
    this.seatsBooked = _busBooking.getSelectedSeats()
    this.passengerDetails = _busBooking.getPassengerDetails()
    this.searchDetails = _busService.getBusFilterDetails()
    console.log(this.searchDetails)
    console.log(this.busBooked)
  }

  ngOnInit(): void {
    
  }

  generateTicketId() {
    return '_' + Math.random().toString(36).substr(2, 12); 
  }

  toggleToGetTicket() {
    this.ticketId = this.generateTicketId()
    console.log(this.ticketId)
    this.getReviewTicket = !this.getReviewTicket;
  }

}

import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { BookingService } from 'src/app/services/booking-service/booking.service';
import { BusService } from 'src/app/services/bus-service/bus.service';

@Component({
  selector: 'app-book-bus',
  templateUrl: './book-bus.component.html',
  styleUrls: ['./book-bus.component.css']
})
export class BookBusComponent implements OnInit {

  busIdSelected: any;
  selectedBus: any = []; 
  
  seatPlan: any[] = [];
  selectedSeats: any[] =[];
  totalFare: any;

  constructor(private _activatedRoute: ActivatedRoute, private _busService: BusService, 
  private _busBooking: BookingService, private _router: Router) 
  { 
    for(let x=0; x<9; x++) {
      this.seatPlan.push([x*4+1, x*4+2, x*4+3, x*4+4]);
    }
  }

  ngOnInit(): void {
    this.getBusIdParam();
  }


  getBusIdParam(){
      this._activatedRoute.paramMap.subscribe((params: ParamMap)=>{
        this.busIdSelected= params.get('id')});
        console.log(this.busIdSelected);

        this.selectedBus = this.getSelectedBusDetails();
        this._busBooking.setBusSelected(this.selectedBus)
        console.log(this.selectedBus);
  }


  getSelectedBusDetails() {
    return this._busService.getBusById(this.busIdSelected);
  }


  isSeatsSelected() {
    if(this.selectedSeats.length == 0)
      return false;
    else
      return true;
  }


  modifySelectedSeats(seatNumber: any) {
    if(this.selectedSeats.includes(seatNumber))
      this.deselectSeat(seatNumber);
    else
      this.selectedSeats.push(seatNumber);
      
    this._busBooking.updateSelectedSeats(this.selectedSeats)
    this.calculateTotalFare();
    console.log(this.selectedSeats);
  }


  deselectSeat(seatNumber: any) {
    this.selectedSeats.forEach((value,index)=>{
      if(value==seatNumber) this.selectedSeats.splice(index,1)});
  }

  calculateTotalFare() {
    this.totalFare = (this.selectedBus.Fare)*(this.selectedSeats.length);
  }

  navigateToPassengerInfo() {
    this._router.navigateByUrl('/passenger-info');
  }

}

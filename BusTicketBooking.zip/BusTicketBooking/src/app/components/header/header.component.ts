import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {

  navbarOpen: boolean = false

  constructor(private _router: Router) { }

  toggleNavbar() {
    this.navbarOpen = !this.navbarOpen;
  }

  isHomePage() {
    let isHomePage = true
    if(this._router.url == '/' || this._router.url == '/home')
      isHomePage = true
    else 
      isHomePage = false

    return isHomePage
  }

  searchBuses() {
    this._router.navigateByUrl('/search-buses');
  }

  goToHome() {
    this._router.navigateByUrl('/home'); 
  }
}
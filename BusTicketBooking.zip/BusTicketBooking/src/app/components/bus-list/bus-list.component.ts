import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BusService } from '../../services/bus-service/bus.service';

@Component({
  selector: 'app-bus-list',
  templateUrl: './bus-list.component.html',
  styleUrls: ['./bus-list.component.css']
})
export class BusListComponent implements OnInit {

  busDetails: any[] = [];
  busFilterCriteria: any = {};

  filteredBusDetails: any[] = [];
  isBusAvailable: boolean = false;
  busTableKeys:string[]= ["Bus Name","Dept. Time","Coach Type","Seats Available","Fare"];

  constructor(private _busService : BusService, private _activatedRoute: ActivatedRoute, private _router: Router) { 
    this.busDetails = _busService.getBusDetails();
    this.busFilterCriteria = _busService.getBusFilterDetails();
    this.filterBusDetails(this.busFilterCriteria);
    console.log(this.filteredBusDetails)
  }

  ngOnInit(): void { }


  getDepartureDay(busFilterCriteria: any) {
    let departureDay;
    let dayValue = new Date(busFilterCriteria.departureDate).getDay();
    console.log(dayValue);

    switch(dayValue){
      case 0: departureDay = "Sunday";
        break;
      case 1: departureDay = "Monday";
        break;
      case 2: departureDay = "Tuesday";
        break;
      case 3: departureDay = "Wednesday";
        break;
      case 4: departureDay = "Thursday";
        break;
      case 5: departureDay = "Friday";
        break;
      case 6: departureDay = "Saturday";
        break;
      default: departureDay = "Error";
    }

    return departureDay;
  }


  filterBusDetails(busFilterCriteria: any) {
    var departureDay = this.getDepartureDay(busFilterCriteria);  
    console.log(departureDay);

  
    this.filteredBusDetails = this.busDetails.filter( bus=> (bus.From === busFilterCriteria.from) &&
    (bus.To === busFilterCriteria.to) && (bus.Days.includes(departureDay)))

    if(this.filteredBusDetails.length)
      this.isBusAvailable = true;
  }

  routeToBus(BusId: any){
    this._router.navigateByUrl('/book/BusId');
  }
}
